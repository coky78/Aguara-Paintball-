# Aguará Paintball

Proyecto estático listo para publicar en Vercel.

Archivos principales:
- index.html
- style.css
- script.js
- vercel.json
- img/

Para publicar: subí esta carpeta/proyecto a Vercel como proyecto nuevo.
El dominio gratuito será del tipo `tu-proyecto.vercel.app`.

Reemplazá `img/hero-placeholder.jpg` por el logo/foto original cuando esté disponible.
